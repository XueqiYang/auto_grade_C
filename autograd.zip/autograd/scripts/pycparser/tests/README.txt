Run 'python -m unittest discover' from the root pycparser directory
